angular.module('ContactsManager', ['ngRoute', 'ngResource', 'firebase'])

.factory('contacts', function($resource, $firebaseArray){
	var firebase = new Firebase('https://blinding-inferno-3999.firebaseio.com/contacts');
	var contacts = $firebaseArray(firebase);

	return {
		get: function(){
			return contacts;
		},
		create: function(contact){
			contacts.$add(contact);
		},
		destroy: function(contact){
			contacts.$remove(contact);
		}
	};
})

.controller('AppCtrl', function($scope, $location){
	$scope.startSearch = function(){
		$location.path('/');
	};
	$scope.isActive= function(path){
		return (path == $location.path()) ? 'active' : '';
	};
})

.controller('BrowseCtrl', function($scope, contacts){
	$scope.contacts = contacts.get();
	$scope.delete = function(contact){
		contacts.destroy(contact);
	};
})

.controller('AddCtrl', function($scope, contacts){
	$scope.submit = function(){
		contacts.create($scope.contact);
		$scope.contact = null;
		$scope.added = true;
	};
})

.config(function($routeProvider){
	$routeProvider.when('/', {
		controller: 'BrowseCtrl',
		templateUrl: 'views/browse.html'
	})
	.when('/add', {
		controller: 'AddCtrl',
		templateUrl: 'views/add.html'
	});
});